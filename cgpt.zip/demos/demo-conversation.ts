import dotenv from 'dotenv-safe'
import { oraPromise } from 'ora'

import { ChatGPTAPI } from '../src'

dotenv.config()

/**
 * Demo CLI for testing conversation support.
 *
 * ```
 * npx tsx demos/demo-conversation.ts
 * ```
 */
async function main() {
  const email = process.env.OPENAI_EMAIL
  const password = process.env.OPENAI_PASSWORD

  const authInfo = {
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.54',
    clearanceToken: 'd8F424AZzN_p.J2LNY8ids3J.PQc.SGjxwqL7RaHSQU-1672177747-0-1-1788ea8f.e50fa1bf.4089b56f-160',
    sessionToken: 'eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2R0NNIn0..7vUyD2mEWMzSh3On.jlpDmaxXpXQwdjSfuHDH565UnAfWUf2czwXNztCMXNbbhAhcJjJ774Sg9V4kT7fXcO24DCF9UozCtB5Yq8NjXNLUrc8Ivy_weG9jQk5Wk9NJcufoBhCb5RlGR3_2-vru29nNUHEooa4RAXY8l9UR0NQ-v9zk8ZVVhCLVGC7as9Gsu6CYRrfv8CtRdSi27tSPn1AnvLH-WDChl3QRYpYxiQzU9Y9kbnTXe64cFUWalYClS8tyaR88ZH5LR7Y730Jq6vtgHnIBNZFd1alGp8nX4G4qwl4zjvEKEtergtnABk-ljs4vs8vM0JYPxZfPGnvxKSlOoCOWI1kIzQCaOu_wS7RobHJlmej2oXxqEP90BdpDzseyu7xzbyngROgy25lBULWgsLNEgIAF09-SyC7qhtpZAAwnnZsP58CNZxT6U3fNOydOqbNMARLOgDqglbZXag6PWHoJlnZEvUFlTK8LSklzJT-FfpAQcpLWb2jB2WUPlk7NAVBQo2z44N0T9-JWJv2fUcNmCm2WFU5E87QxI76_lGpfZAeVSFOkRXPxF3goOCS_EQUlZaUbcKZs32lCCYkXusRuydhB-ZFh924xsPGi19n_Xlf7wn6Ro5oTVRRCa1LbqzxoKFfFJ46Yn0IveeKZowZDNCUAFPgVUOpoRIP6UMhD3Lt9Us1WjOTojYRGxUNDFrjapWgj6OPZygWM0Fa8jAUGd_zKKsaI1UQu8DWHiAIcg5ghFYka2dXj_2JKJg6DkAtM16idXoYpTgJCqlV1Wj4u5V7I0zPiO9LO8GucwZ-DhFpnONoFe3fEirO-eTuQZzkK7-KGc2WOqY8rOOnM8-yGV7TzvtkK3-spq5EQY929lh4E08hbNEo62w9b1eaXFcugKULB3p8M8DGHgUy5jGXlRn28UvsZkrNmf2B0ZJEEcacFnfUDzkKymUnb3W6_aIxKijXjoQ10oWliDRLOo6FHY8VkSWIz524CrMN1sV9U4R406eqDQ6sqI-nGN9QYLklI5scVULoULkgkk5YTqupK2YoisfNS_tjmMd4EIIA9q2k0PSDSHzDvMY5AjeRFULFoUCfmGGe9INxaNA5TUAoiGiob2ZBd41hXiNDEq9lS-MVFDp9oqGB2nvbnmC3n75XUi9kImjxiIYXCxi1FuR1_oqlTLCobuwRFo_YBHzfGLFDe_ZRH3HBO6TR-6AD0bVqjvW18vs9g76aQdeS-oo3c0jStn19rJ1Sv_qs_8BFNOCNLqt_RgY5rS6SMXCqdpev60kqTZCzMjkgMO2rseAqPMryucRl1MjSqvxoJOuu43wSbLmrK-tREhPcJI_lptPA92_f3o2iSfDU_GmdzPLqWz_vDQFQOhEGOfd0dwqfFFuSTVk1r5pN6zWiN-2-SMCAGk0HvRggLy7i_n1MtgoGztl2LJ7zJRUekv6OXQ9hyHACPMW3IRQA1p6m5v_nAXBFHP96lrWrmo740xb7PDglgXMsFgfXbEHGN0xRoDInWkzopA6LugsyYNgPF_ObQBRAPohcR4KNSb63hllpG6AMIeFH6J3zHlCwtCwzUTAJAy9DqRlrY4TuAnFYeqwmlzKvagTCR1XiLEUuXxGkwOO3pxYxH8SBa-MLNDJfvK3ZGKv3P9lZr6Pc9KB68htGnSCfUPzW8cumJvsc9TwNN2OL42G8s88gjZJNJmuqOpfGeYnEcRns0m46kiZL_0nqixPOUsuPxv4YiiDzhA2npwFqVRKobMhP0l2LG8G6ITkk44nqJyN90_LLzO65A9vhHfiJkJGg7dSeNg4uuP6Q_de4P03bjyBRlskIknF1xu3SWZOXR9ltFxtz9bUXoR0hus9qfAIcOsBZEfltXyJZA96MGQnv2cv2UsJsmlAncZwgXbKuQACQDB9KmlCXYWqlGBg0NZincMYw749lCXwHpG5XWsNdF6N8i8K8R-DD0rS2Z5nkZXSb7m3ubMb68_PJBMy8YGsM5Q0Bj57ESeY1cG6kY7RozPMQIAV6rbPNZnBdAD7FEmQet8zmDAfZjIMgjKHsp5CPWntvRe6_TfjvFSWktrfbya_L_YqpfWMAEuRKUGJbexutnmRvfGCXknOSm8sKvKbvL6Rwtm0pOflboUQ6KeWBLV1aBrHv-_1MFohSamWGrYY7DafZtM-dPJ-2ZZoN5AACPEj2auLknAA2EbntIhQ9r-rOzrw8_kY0TrqEIifmyQ7Sk1PWZHENoqCX5XYjb1TadkYs9xjJV_Fi16K1CdmSW7l2AZw0NDT_zRXV11gV-Q4ESboqevCMsP9bprNKU6DVYnUvwX53hcsxox1qAMcRCm4nxjUmJyEkcKBn0Xu6U3UPSh4W_NQkz7jfk23gCNWjkOPFVN0MZXZ9H.hrVGe6lXYVV7Mw3qgmahlw'
      + ' _ga=GA1.2.1147387887.1671774982; intercom-device-id-dgkjq2bp=2803d4f6-63de-4260-a258-6f79bd870c79; intercom-session-dgkjq2bp=bk9FS1JtS25yWUhNK3laalFQUlh4N2srODZqWDFRTTFId2UrMVkwZXc2ZXhnZjlMdnZhc2F2aU5tcUkxN0Fmbi0tWVhxL2xOeFNPNllmaHExaHVJTVF4dz09--508c4953c6ed9b19a90b92edc6bc57ce7a6feb7e; __Host-next-auth.csrf-token=41d8ae0e235c472e470fc659329e7d7794624b414dffa88a67a510962f026096%7C5449f4a8925296229143aa6c3b98ac36e65e54c7830e745f29896d4fb66398d5; __Secure-next-auth.callback-url=https%3A%2F%2Fchat.openai.com; cf_clearance=Ir78pzBAOjdBY.ya4R.iFAq4J291J7S0OgNqwz.r83Y-1672175176-0-1-f0e18e5b.55be14cc.a7e0d1bb-160; _cfuvid=Oea7FIXTosfElQfJyQkx0h3ONxQaIvANGITo75DU.7Q-1672175176928-0-604800000; __cf_bm=iQvsLm7PA2k2tIDhLBTLO8FqJ.8XX05y47qUImmBzrc-1672175702-0-AelFpzjlwevQ3HMaE3nBOs7oBH7DSVHegctuFewnH5XPh3N+07UE9IComeawCLa2YLRDbU3uCEbQ9XnOCjYlAPnGUW1fhjvo4wToIVJiJ/8BetaWSkmDrwgWE7bQI+p1mdTUC0JrHAITpPh/42TACp0lLjwTYzFt/TFOF/sH2YbuDEFRuyB/zb/ZJP5NJOjHlA==;'
  }

  const api = new ChatGPTAPI({ ...authInfo })
  console.log('开始初始化seesion')
  await api.initSession()
  console.log('结束初始化seesion')
  const prompt = 'Write a poem about cats.'

  let res = await oraPromise(api.sendMessage(prompt), {
    text: prompt
  })

  console.log('\n' + res.response + '\n')

  const prompt2 = 'Can you make it cuter and shorter?'

  res = await oraPromise(
    api.sendMessage(prompt2, {
      conversationId: res.conversationId,
      parentMessageId: res.messageId
    }),
    {
      text: prompt2
    }
  )
  console.log('\n' + res.response + '\n')

  const prompt3 = 'Now write it in French.'

  res = await oraPromise(
    api.sendMessage(prompt3, {
      conversationId: res.conversationId,
      parentMessageId: res.messageId
    }),
    {
      text: prompt3
    }
  )
  console.log('\n' + res.response + '\n')

  const prompt4 = 'What were we talking about again?'

  res = await oraPromise(
    api.sendMessage(prompt4, {
      conversationId: res.conversationId,
      parentMessageId: res.messageId
    }),
    {
      text: prompt4
    }
  )
  console.log('\n' + res.response + '\n')

  await api.closeSession()
}

main().catch((err) => {
  console.error(err)
  process.exit(1)
})
